<?php

namespace FacturaScripts\Plugins\eCF_GMV\Extension\Model;

class Cliente
{
    public function clear(): \Closure
    {
        return function () {
            $this->url_recepcion_ecf = '';
        };
    }
}
