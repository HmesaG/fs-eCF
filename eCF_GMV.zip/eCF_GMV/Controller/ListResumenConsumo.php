<?php

namespace FacturaScripts\Plugins\eCF_GMV\Controller;

use FacturaScripts\Core\Lib\ExtendedController\ListController;
use FacturaScripts\Plugins\eCF_GMV\Lib\DGII\DgiiResumenServicio;

class ListResumenConsumo extends ListController
{
    public function getPageData(): array
    {
        $data = parent::getPageData();
        $data['title'] = 'Resumen de Consumo (RFCE)';
        $data['menu'] = 'eCF';
        $data['icon'] = 'fas fa-file-invoice-dollar';
        return $data;
    }

    protected function createViews(): void
    {
        $this->addView('ListResumenConsumo', 'ResumenConsumo');
    }

    /**
     * En este controlador no listamos una tabla directamente desde la DB,
     * sino que usamos el servicio para obtener los días pendientes.
     */
    protected function loadData($viewName, $view = null)
    {
        switch ($viewName) {
            case 'ListResumenConsumo':
                $this->views[$viewName]->data = DgiiResumenServicio::getPendientes();
                break;
        }
    }

    public function processAction(string $action): void
    {
        if ($action === 'procesar' && !empty($this->request->get('fecha'))) {
            $fechaStr = $this->request->get('fecha');
            try {
                $fecha = new \DateTime($fechaStr);
                $res = DgiiResumenServicio::procesarDia($fecha);
                
                if ($res['status'] === 'success') {
                    $this->toolBox()->display()->info($res['mensaje']);
                } elseif ($res['status'] === 'info') {
                    $this->toolBox()->display()->warning($res['mensaje']);
                } else {
                    $this->toolBox()->display()->error($res['mensaje']);
                }
            } catch (\Exception $e) {
                $this->toolBox()->display()->error('Error: ' . $e->getMessage());
            }
        }
    }
}
